﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.Readers;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Threading;
using System.ComponentModel;
using EqParser.Closer;
using EqParser.SyntLexems;
using EqParser.IO;



namespace EqParser.SyntLexems
{


    class Program
    {
       

        static Thread workerThread = new Thread(CheckErrors);
        static int mainProcessId;


        static void Main(string[] args)
        {
            //Console.TreatControlCAsInput = false;

            Console.CancelKeyPress += new ConsoleCancelEventHandler(Closer);

            mainProcessId = Process.GetCurrentProcess().Id;


            CheckErrors();

            // Console.ReadKey();
        }



        static void CheckErrors()
        {
            Reader reader = new Reader();

            reader.Read();

        }

        protected static void Closer(object sender, ConsoleCancelEventArgs args)
        {

            args.Cancel = true;

            KillConsole.kill.BeginInvoke(mainProcessId, null, null);

        }

    }
}
