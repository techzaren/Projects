﻿using System;
using System.Text;
using System.Threading.Tasks;
using EqParser.Readers;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Threading;
using System.ComponentModel;

namespace EqParser.Closer
{
    public static class KillConsole
    {

        public delegate void Killerss(int processId);
        public static Killerss kill = Close;



        [StructLayout(LayoutKind.Sequential)]
        struct PROCESS_BASIC_INFORMATION
        {
            public uint ExitStatus;
            public IntPtr PebBaseAddress; // 0 если 32-бит-ый процесс пытается получить инфу о 64-х битном процессе
            public IntPtr AffinityMask;
            public int BasePriority;
            public IntPtr UniqueProcessId;
            public IntPtr InheritedFromUniqueProcessId;
        }


        #region DllImport

        [DllImport("ntdll.dll", SetLastError = true, ExactSpelling = true)]
        private static extern uint NtQueryInformationProcess(
            IntPtr ProcessHandle,
            uint ProcessInformationClass,
            ref PROCESS_BASIC_INFORMATION ProcessInformation,
            int ProcessInformationLength,
            out int ReturnLength
            );

        
        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, IntPtr dwProcessId);

        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
        static extern bool CloseHandle(IntPtr hObject);

        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
        static extern bool TerminateProcess(int hProcess, uint uExitCode);

        const uint PROCESS_TERMINATE = 0x1;

        #endregion

        static private void TerminateProcess(IntPtr PID)
        {
            IntPtr hProcess = OpenProcess(PROCESS_TERMINATE, false, PID);


            if (hProcess == IntPtr.Zero)
            {
                throw new Win32Exception(System.Runtime.InteropServices.Marshal.GetLastWin32Error());
            }

            if (!TerminateProcess((int)hProcess, 0))
            {
                throw new Win32Exception(System.Runtime.InteropServices.Marshal.GetLastWin32Error());
            }

            CloseHandle(hProcess);
        }


        public static void Close(int procId)
        {

            System.Diagnostics.Process someOneProcess = System.Diagnostics.Process.GetProcessById(procId);

            IntPtr mainProcessID = (IntPtr)someOneProcess.Id;

            using (var process = Process.GetProcessById(procId))
            {
                var basicInfo = new PROCESS_BASIC_INFORMATION();
                int writed;

                if (0 != NtQueryInformationProcess(process.Handle, 0, ref basicInfo, Marshal.SizeOf(basicInfo), out writed) ||
                     writed == 0)
                    throw new Win32Exception(Marshal.GetLastWin32Error());

                mainProcessID = basicInfo.InheritedFromUniqueProcessId;
                
            }




            System.Diagnostics.Process[] processList = System.Diagnostics.Process.GetProcessesByName("cmd");

            foreach (var pr in processList)
            {
                if (pr.ProcessName.StartsWith("cmd"))
                {

                    TerminateProcess(mainProcessID);

                }

            }


            TerminateProcess((IntPtr)procId);





        }



    }

}

