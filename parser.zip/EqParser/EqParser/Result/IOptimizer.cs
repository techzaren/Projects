﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;
using EqParser.Shapers;
using EqParser.Shapers.Data;

namespace EqParser.Result
{
    interface IOptimizer
    {
        void StartOptimize(Keeper keeper);
    }
}
