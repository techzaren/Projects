﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.Shapers;
using EqParser.Shapers.Data;
using EqParser.SyntLexems;


namespace EqParser.Result
{
    sealed public class Optimizer: IOptimizer
    {
        Shaper shaper = new Shaper();
        Merger merger = new Merger();
        ResultStr result = new ResultStr();




        /// <summary>
        /// Именно этот метод запускает механизм оптимизации
        /// </summary>
        /// <param name="keeper"></param>
        public void StartOptimize(Keeper keeper)
        {
            shaper.Shape(keeper);
            merger.Merge(keeper);


            result.GetResult(keeper);


        }

    }
}
