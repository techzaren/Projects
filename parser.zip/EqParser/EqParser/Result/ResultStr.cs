﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.Shapers;
using EqParser.Shapers.Data;
using EqParser.SyntLexems;
using EqParser.IO;

namespace EqParser.Result
{
   sealed class ResultStr
    {
        SimilarTerms similarTerms = new SimilarTerms();
        ResultReader resulReader = new ResultReader();
        Writer writer = new Writer();

       /// <summary>
       /// Доводит работу до конца и выводит через writer-a результат
       /// </summary>
       /// <param name="keeper"></param>
        public void GetResult(Keeper keeper)
        {
            
            similarTerms.GetSimilarTerms(keeper.LeftPart);

            var resultStr = resulReader.ReadResult(keeper.LeftPart) + " = 0";

            WriteResult(resultStr);
        }

        public void WriteResult(string resultStr)
        {
            writer.Write(resultStr);
            writer.Record(resultStr);
        
        }


    }
}
