﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EqParser.IO
{
   public class Writer
    {

      public void Write(string result)
       {
           Console.WriteLine(result);
       
       }


      public void Record(string inputStr)
      { 
       
        FileStream file = new FileStream("result.out", FileMode.Append); 
        StreamWriter writer = new StreamWriter(file); 
        writer.WriteLine(inputStr); 
        writer.Close(); 


      }

      public void WriteEmpty()
      {
          Console.WriteLine("");
      
      }


    }
}
