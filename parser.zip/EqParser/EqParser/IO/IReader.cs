﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqParser.IO
{
    interface IReader
    {

        void Read();

        void Select();

        void ReadLine();

        void ReadCurrentDirectory();

        void ReadPath();

    }
}
