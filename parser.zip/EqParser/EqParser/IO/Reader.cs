﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.Readers;
using EqParser.SyntLexems;
using EqParser.Shapers;
using EqParser.Result;
using EqParser.Shapers.Data;



namespace EqParser.IO
{
    sealed public class Reader
    {
        ErrorDetector errDetector;
        Splitter splitter;
        Optimizer optimizer;
        Writer writer = new Writer();



        public void Read()
        {

            writer.Write("Для ввода выражения введите - 1\nДля чтения выражения из файла - 2");

            switch (Console.ReadKey().KeyChar)
            {

                case '1':
                    ReadLine();
                    break;

                case '2':
                    Select();
                    break;

                default:
                    Error();
                    break;


            }




        }


        private void Select()
        {
            Console.Clear();
            Console.WriteLine("Введите - 1 чтобы прочитать выражение из текущей дериктории\nВведите - 2, чтобы указать путь к файлу");

            switch (Console.ReadKey().KeyChar)
            {
                case '1':
                    ReadCurrentDirectory();
                    break;

                case '2':
                    ReadPath();
                    break;

                default:
                    Error();
                    break;

            }
        }

        private void Error()
        {
            Console.Clear();
            writer.Write("Неверная команда, повторите ввод");
            Read();

        }

        private void ReadLine()
        {
            Console.Clear();
            splitter = new Splitter();
            optimizer = new Optimizer();
            errDetector = new ErrorDetector();


            Console.Write("Введите выражение: ");


            if (errDetector.DetectError(Console.ReadLine()) != null)
            {
                var keeper = splitter.GetDataKeeper(errDetector.CheckedString);
                if (keeper != null)
                {
                    optimizer.StartOptimize(keeper);

                }


            }

            Read();

        }


        private void ReadCurrentDirectory()
        {
            Console.Clear();
            string line;
            splitter = new Splitter();
            errDetector = new ErrorDetector();

            System.IO.StreamReader file =
            new System.IO.StreamReader(Environment.CurrentDirectory + "\\eq.txt");



            while ((line = file.ReadLine()) != null)
            {
                
                optimizer = new Optimizer();
                

                if (errDetector.DetectError(line) != null)
                {
                    writer.WriteEmpty();

                    var keeper = splitter.GetDataKeeper(errDetector.CheckedString);
                    if (keeper != null)
                    {
                        optimizer.StartOptimize(keeper);

                        writer.WriteEmpty();

                    }


                }

            }

            file.Close();

            Read();

        }

        private void ReadPath()
        {
            splitter = new Splitter();
            
            errDetector = new ErrorDetector();

            Console.Clear();


            writer.Write("Введите путь файла и его имя");
            string line;
            

            System.IO.StreamReader file =
            new System.IO.StreamReader(Console.ReadLine());


            while ((line = file.ReadLine()) != null)
            {
                optimizer = new Optimizer();

                if (errDetector.DetectError(line) != null)
                {
                    writer.WriteEmpty();

                    var keeper = splitter.GetDataKeeper(errDetector.CheckedString);
                    if (keeper != null)
                    {
                        optimizer.StartOptimize(keeper);

                        writer.WriteEmpty();
                    }


                }

            }

            file.Close();

            Read();

        }


    }
}
