﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqParser.SyntLexems
{
    public interface IDataList
    {
        #region Реализовано
        
        VariablesDate AddNewBranch(VariablesDate inputBranch);
        VariablesDate CreateNewBranch(bool alreadyWritten, bool closed, char sign, float coeff, string var);
        void SaveData(bool closed, char sign, float coeff, string var);

        #endregion

        #region Реализовать

        #endregion
    }
}
