﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.Readers;


namespace EqParser.SyntLexems
{
    public class Parser
    {
        #region Переменные
        //public Action<string> GetLexMethod;

        Precedence precedence = new Precedence();
        #endregion


        #region Методы


        public VariablesDate Parse(string somePart)
        {
            var lexemList = (List<string>)GetLexem(somePart);

            return GetEquationPart(lexemList);

        }


        /// <summary>
        /// Преобразует входящую строку в коллекцию лексем
        /// </summary>
        /// <param name="InputStr"></param>
        /// <returns></returns>
        private IEnumerable<string> GetLexem(string InputStr)
        {
            var operators = new[] { Symbols.Plus, Symbols.Minus, Symbols.LeftBracket, Symbols.Multiplication };
            var result = new List<string>();
            bool separationDeterminant = false;

            var currentLexem = string.Empty;

            foreach (var currentChar in InputStr)
            {

                if ((currentLexem.Length > 0) && (currentLexem[currentLexem.Length - 1] == '(' || currentLexem[currentLexem.Length - 1] == '^' || currentLexem[currentLexem.Length - 1] == '/'))
                {
                    separationDeterminant = true;
                }

                if ((operators.Contains(currentChar) && currentChar != Symbols.LeftBracket && currentChar != Symbols.DegreeSymbol && currentChar != Symbols.Division) || separationDeterminant == true)//currentChar != Symbols.LeftBracket
                {

                    if (currentLexem != string.Empty)
                    {
                        result.Add(currentLexem);

                    }

                    currentLexem = string.Empty;
                    separationDeterminant = false;
                }

                currentLexem += currentChar;

            }
            result.Add(currentLexem);

            return result;
        }

        private VariablesDate GetEquationPart(List<string> lexemList)
        {
            var MainTree = new VariablesDate();
            var currentReader = MainTree.Self;
            var tempReader = MainTree;

            foreach (string currentLexem in lexemList)
            {
                tempReader = CreateExpression(currentLexem, currentReader.NextReader);

                if (tempReader.AlreadyWritten)
                {
                    currentReader = tempReader.NextReader;
                }

                else
                {
                    if (currentReader == tempReader.Parent)
                    {
                        currentReader.AddNewBranch(tempReader);
                        currentReader = currentReader.DataList[currentReader.DataList.Count - 1].NextReader;


                    }

                    else
                    {
                        currentReader = tempReader.Parent;                  //когда после ^выражение или /выражение   идут операторы -  +  
                        currentReader.AddNewBranch(tempReader);             // они меняют своего родителя c ^ или / на родителя порадивщего ^ или /
                        currentReader = tempReader.NextReader;              // смена родителя происходит в CreateExpression, здесь уже идёт только переопределение 
                        // текущего читателя.
                    }

                }
            }


            return MainTree;

        }


        /// <summary>
        /// Получить отношение предшествования между двумя лексемами
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns></returns>
        private char CalculatePrecedence(char left, char right)
        {
            char leftSymbol = precedence.LexemIdentificator(left);
            char rightSymbol = precedence.LexemIdentificator(right);

            return precedence.GetPrecedence(leftSymbol, rightSymbol);
        }

        private VariablesDate CreateExpression(string lexem, VariablesDate parent)
        {
            #region Переменные
            var ExpressionsCreator = new ExpressionsCreator();
            var Precedence = new Precedence();
            var mainThree = new VariablesDate(parent);
            char precedenceResult;
            // string _var = Symbols.HashSymbol.ToString();
            string _tempLexem = string.Empty;
            #endregion

            #region Тело
            using (MyCharEnumerator charPointer = new MyCharEnumerator(lexem), secondCharPointer = new MyCharEnumerator(lexem, 0))
            {
                if (secondCharPointer.MoveNext())
                {
                    while (charPointer.MoveNext() && secondCharPointer.IsHasValue)
                    {
                        precedenceResult = CalculatePrecedence(charPointer.Current, secondCharPointer.Current);
                        _tempLexem += charPointer.Current;

                        if (precedenceResult != '=')
                        {
                            ExpressionsCreator.SelectRecordingMethod(precedenceResult);
                            mainThree = ExpressionsCreator.MethodSelector(mainThree, _tempLexem);

                            _tempLexem = string.Empty;
                        }

                        secondCharPointer.MoveNext();

                    }

                    if (charPointer.IsLast && mainThree.AlreadyWritten == false)
                    {
                        _tempLexem += charPointer.Current;
                        ExpressionsCreator.SelectRecordingMethod('L');
                        mainThree = ExpressionsCreator.MethodSelector(mainThree, _tempLexem);

                    }
                }

                else
                {
                    if (charPointer.MoveNext())
                    {
                        _tempLexem += charPointer.Current;
                        ExpressionsCreator.SelectRecordingMethod('L');
                        mainThree = ExpressionsCreator.MethodSelector(mainThree, _tempLexem);

                        _tempLexem = string.Empty;

                    }


                }

            }



            return mainThree;

        }

            #endregion
       

        
        
        #endregion


        #region Конструкторы
        public Parser()
        {


        }
        #endregion

    }
}
