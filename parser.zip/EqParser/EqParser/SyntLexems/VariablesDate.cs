﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections;


namespace EqParser.SyntLexems
{
   sealed public class VariablesDate : IDataList, IEnumerable
    {
        #region Переменные
        private VariablesDate _parent = null;         //ссылка на родителя (для обхода дерева)
        private VariablesDate _self = null;
        private VariablesDate _NextReader = null;

        private bool _alreadyWritten = false;
        private bool _closed = false;
        public List<List<VariablesDate>> listoflist = null;
        private List<VariablesDate> _dataList = new List<VariablesDate>(); //сохраняем здесь ^ например в виде целого выражения (2b+4bc)
        private char _sign;                          //знак перед переменной/константой
        private float _coeff;                         //коэффециент переменной
        private int _bracketType;                     //тип скобок в котором содержится данная переменная/константа или их отсутствие
        private string _var;                          //Переменные
        private bool _bracketOptimizedThree = false;
        private bool _termsOptimizedThree = false;
        private bool _movedBracket = false;
        private bool _writtenRightBracket = false;
        private bool _readed = false;
        private int _indexInParentData;
        #endregion


        IEnumerator IEnumerable.GetEnumerator()
        {
            return DataList.GetEnumerator();
        }







        #region Свойства


        public VariablesDate Parent
        {
            get { return _parent; }

            set { _parent = value; }
        }

        public VariablesDate Self
        {
            get { return _self; }

            private set { _self = value; }
        }

        public VariablesDate NextReader
        {
            get { return _NextReader; }

            set { _NextReader = value; }
        }

        public bool AlreadyWritten
        {
            get { return _alreadyWritten; }

            set { _alreadyWritten = value; }
        }

        public bool Closed
        {
            get { return _closed; }

            set { _closed = value; }
        }

        public List<VariablesDate> DataList
        {
            get { return _dataList; }

            set { _dataList = value; }
        }
        public char Sign
        {
            get { return _sign; }
            set { _sign = value; }
        }


        public float Coeff
        {
            get { return _coeff; }
            set { _coeff = value; }
        }

        public int BracketType
        {
            get { return _bracketType; }
            set { _bracketType = value; }
        }


        public string Var
        {
            get { return _var; }
            set { _var = value; }
        }


        public bool BracketOptimizedThree
        {
            get { return _bracketOptimizedThree; }
            set { _bracketOptimizedThree = value; }

        }


        public bool TermsOptimizedThree
        {
            get { return _termsOptimizedThree; }
            set { _termsOptimizedThree = value; }

        }

        public bool MovedBracket
        {
            get { return _movedBracket; }
            set { _movedBracket = value; }

        }

        public bool Readed
        {
            get { return _readed; }
            set { _readed = value; }

        }

        public bool RightBracketIsWritten
        {
            get { return _writtenRightBracket; }
            set { _writtenRightBracket = value; }

        }

        public int Index
        {
            get { return _indexInParentData; }
            set { _indexInParentData = value; }

        }



        #endregion

        #region Методы

        public VariablesDate AddNewBranch(VariablesDate inputBranch)
        {
            // у базового класса лист был создан базовым конструктором,
            //  а остальным классам инициализированный лист нужен только при добавлении подкласса        //коммент

            if (DataList == null)
            {

                DataList = new List<VariablesDate>();
            }

            DataList.Add(inputBranch);

            return DataList[DataList.Count - 1];


        }

        public VariablesDate CreateNewBranch(bool alreadyWritten = false, bool closed = false, char sign = Symbols.Plus, float coeff = 1.0f, string var = "#")
        {
            // у базового класса лист был создан базовым конструктором,
            //  а остальным классам инициализированный лист нужен только при добавлении подкласса //коммент

            if (DataList == null)
            {

                DataList = new List<VariablesDate>();
            }


            DataList.Add(new VariablesDate(this, alreadyWritten, closed, sign, coeff, var));



            return DataList[DataList.Count - 1];


        }


        public void SaveData(bool closed = false, char sign = Symbols.Plus, float coeff = 1.0f, string var = "#")
        {
            Sign = sign;
            Coeff = coeff;
            Var = var;
            Closed = closed;
        }


        public VariablesDate Empty(VariablesDate parent = null)
        {
            return new VariablesDate(parent, false, false, Symbols.Plus, 0f, "0");

        }

        public string GetParentPointer()
        {
            return Parent.ToString();

        }




        #endregion


        #region Конструкторы
        public VariablesDate()
        {
            DataList = new List<VariablesDate>();
            Parent = this;
            Coeff = 1.0f;
            Self = this;
            NextReader = Self;
            Var = "Я самый старший класс из всех";


        }

        public VariablesDate(VariablesDate parent)
        {

            Parent = parent;
            Self = this;
            NextReader = parent;
            AlreadyWritten = false;
            Closed = false;

            Sign = Symbols.Plus;
            Coeff = 1.0f;
            Var = "#";


        }

        public VariablesDate(VariablesDate par = null, bool alreadyWritten = false, bool closed = false, char sign = Symbols.Plus, float coeff = 1.0f, string var = "#")
        {

            Parent = par;
            Self = this;
            NextReader = Self;
            AlreadyWritten = alreadyWritten;
            Closed = closed;
            Sign = sign;
            Coeff = coeff;
            Var = var;


        }


        #endregion




    }
}
