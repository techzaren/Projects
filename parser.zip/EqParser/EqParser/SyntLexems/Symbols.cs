﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqParser.SyntLexems
{
    public static class Symbols
    {
        #region Константы
        public const char HashSymbol = '#';
        public const char Plus = '+';
        public const char Minus = '-';
        public const char Equality = '=';
        public const char Division = '/';
        public const char Multiplication = '*';
        public const char DegreeSymbol = '^';
        public const char DotSeparator = '.';
        public const char LeftBracket = '(';
        public const char RightBracket = ')';
        #endregion

    }
}
