﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EqParser.SyntLexems
{
    public sealed class MyCharEnumerator : IEnumerator<char>, IDisposable
    {
        #region Переменные
        private string _inputStr;
        private char _currentChar;
        private int _currentIndex;
        #endregion

        #region Свойства
        object IEnumerator.Current
        {
            get { return Current; }
        }

        public char Current
        {
            get
            {
                if (_currentIndex < 0 || _currentIndex >= _inputStr.Length)
                    throw new InvalidOperationException("Index out of bounds");

                return _currentChar;
            }
        }


        public bool IsHasValue
        {
            get { return _currentIndex >= 0 && _currentIndex < _inputStr.Length; }
        }


        public bool IsLast
        {
            get { return _currentIndex >= 0 && _currentIndex == _inputStr.Length - 1; }
        }

        #endregion

        #region Методы
        public bool MoveNext()
        {
            if (_currentIndex < (_inputStr.Length - 1))
            {
                _currentIndex++;
                _currentChar = _inputStr[_currentIndex];
                return true;
            }

            _currentIndex = _inputStr.Length;
            return false;
        }

        public void Reset()
        {
            _currentChar = (char)0;
            _currentIndex = -1;
        }

        public void Dispose()
        {
            if (_inputStr != null)
                _currentIndex = _inputStr.Length;
            _inputStr = null;
        }
        #endregion

        #region Конструкторы
        public MyCharEnumerator(string str)
        {
            if (str == null)
            {
                throw new ArgumentNullException("str is null");
            }
            else

                _inputStr = str;
            _currentIndex = -1;
        }

        public MyCharEnumerator(string str, int startIndex)
        {
            if (str == null)
            {
                throw new ArgumentNullException("str is null");
            }

            else

                _inputStr = str;
            _currentIndex = startIndex;
        }

        #endregion

    }
}
