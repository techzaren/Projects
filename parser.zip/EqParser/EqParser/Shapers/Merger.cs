﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.Shapers.Data;

namespace EqParser.Shapers
{
    sealed class Merger
    {
        /// <summary>
        /// Переводит уже готовую правую часть в левую, 
        /// При этом меняет родителя у всех элементов правой части на родителя левой части
        /// </summary>
        /// <param name="keeper"></param>
        public void Merge(Keeper keeper)
        {
            foreach (var element in keeper.RightPart.DataList)
            {
                keeper.LeftPart.DataList.Add(element);



            }

            foreach (var elements in keeper.LeftPart.DataList)
            {
                elements.Parent = keeper.LeftPart.Self;

            }

        }

    }
}
