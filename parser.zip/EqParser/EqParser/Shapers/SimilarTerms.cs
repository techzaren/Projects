﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using EqParser.SyntLexems;
using EqParser.Shapers.ShapersEnumerators;

namespace EqParser.Shapers
{
    sealed public class SimilarTerms
    {
        #region Методы
        public void GetSimilarTerms(VariablesDate someDataPart)
        {
            var threeRoot = someDataPart;
            var optimizeIsOver = false;


            using (var enumerator = new TermsEnumerator(threeRoot))
            {
                while (!optimizeIsOver)
                {
                    if (GetLastNotOptimizedThree(enumerator).Self != threeRoot.Self)
                    {
                        if (enumerator.MainBranch.Var == "/" || enumerator.MainBranch.Var == "^")
                        {
                            enumerator.MainBranch.TermsOptimizedThree = true;

                            enumerator.MovePreviousClosedBranch();
                        }
                        else
                        {

                            FindSimilarTerms(enumerator);
                            enumerator.MovePreviousClosedBranch();

                        }
                    }

                    else
                    {

                        FindSimilarTerms(enumerator);

                        optimizeIsOver = true;

                    }
                }

            }

        }


        private VariablesDate GetLastNotOptimizedThree(TermsEnumerator enumerator)
        {
            while (enumerator.MoveNextClosedBranch())
            {


            }


            return enumerator.MainBranch;

        }


        private void FindSimilarTerms(TermsEnumerator enumerator)
        {

            var termsList = enumerator.MainBranch.DataList;

            VariablesDate[] terms = termsList.Where(el => ((el.Var[0] == '#' || char.IsLetter(el.Var[0])) && el.Closed == false)).ToArray();



            for (int i = 0; i < terms.Count(); i++)
            {
                for (int j = 0; j < terms.Count(); j++)
                {
                    if (i != j)
                    {
                        ChangeCoeff(terms[i], terms[j]);
                    }

                }

            }

            for (int i = 0; i < termsList.Count; i++)
            {

                for (int index = 0; index < termsList.Count; index++)
                {
                    if (termsList[index].Coeff == 0)
                    {
                        termsList.RemoveAt(index);

                    }
                }

            }



            enumerator.MainBranch.TermsOptimizedThree = true;

        }



        private void ChangeCoeff(VariablesDate first, VariablesDate second)
        {

            float resultCoeff = first.Coeff;

            if (first.Var == second.Var)
            {
                resultCoeff += second.Coeff;
                first.Coeff = resultCoeff;
                second.Coeff = 0.0f;

            }

        }

        #endregion


    }
}
