﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;
using EqParser.Shapers.Data;

namespace EqParser.Shapers
{
   sealed class Shaper: IShaper
    {

        BracketDisclosures branchDisclosures = new BracketDisclosures();
        BracketMover bracketMover = new BracketMover();
        
        




        public Keeper Shape(Keeper keeper)
        {
            branchDisclosures.OpenBrackets(keeper.LeftPart);
            bracketMover.MoveBrackets(keeper.LeftPart);


            branchDisclosures.OpenBrackets(keeper.RightPart);
            bracketMover.MoveBrackets(keeper.RightPart);

            

            return keeper;

        }
            


    }
}
