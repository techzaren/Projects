﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.Shapers.Data;
using EqParser.SyntLexems;

namespace EqParser.Shapers
{
    sealed public class Splitter
    {
        Parser parser = new Parser();

        #region Методы
        private string[] GetSplit(string notSplitedParts)
        {
            var splitedEquation = notSplitedParts.Split(new[] { Symbols.Equality });

            return splitedEquation;

        }

        public Keeper GetDataKeeper(string notSplitedPart)
        {
            var splitedParts = GetSplit(notSplitedPart);


            VariablesDate leftPart = parser.Parse(splitedParts[0]);

            if (splitedParts.Length == 2)
            {
                var str = splitedParts[1];
                str = "-(" + str + ")";
                VariablesDate rightPart = parser.Parse(str);

                return new Keeper(leftPart, rightPart);

            }
            else
                Console.WriteLine("Вы ввели неверное количество знака = \nРабота над текущим выражением остановлена");

            return null;

        }
        #endregion
    }
}
