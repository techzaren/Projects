﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;
using EqParser.Shapers.ShapersEnumerators;

namespace EqParser.Shapers
{
    class BracketMover
    {

        public void MoveBrackets(VariablesDate someDataPart)
        {
            var threeRoot = someDataPart;
            var optimizeIsOver = false;


            using (var enumerator = new MovingEnumerator(threeRoot))
            {
                while (!optimizeIsOver)
                {
                    if (GetLastNotOptimizedThree(enumerator).Self != threeRoot.Self)
                    {
                        if (enumerator.MainBranch.Var == "/" || enumerator.MainBranch.Var == "^")
                        {
                            enumerator.MainBranch.MovedBracket = true;

                            enumerator.MovePreviousClosedBranch();
                        }
                        else
                        {

                            Move(enumerator);


                        }
                    }

                    else
                    {


                        optimizeIsOver = true;

                    }
                }

            }

        }
        /// <summary>
        /// Очень жирный цикл состоящий из пустого тела xD
        /// Если серьёзно, то позволяет дойти до самого последнего скобочного выражения
        /// Это выражение может содержаться хоть на глубине 1млн таких же скобок
        /// </summary>
        /// <param name="enumerator"></param>
        /// <returns></returns>
        private VariablesDate GetLastNotOptimizedThree(MovingEnumerator enumerator)
        {
            while (enumerator.MoveNextClosedBranch())
            {



            }



            return enumerator.MainBranch;

        }
        /// <summary>
        /// Непосредственное перемещение выражений из скобки за её пределы
        /// </summary>
        /// <param name="enumerator"></param>
        private void Move(MovingEnumerator enumerator)
        {
            var bracket = enumerator.MainBranch;
            var elements = bracket.DataList;

            if (CheckPermission(bracket))
            {

                for (int index = 0; index < elements.Count; index++)
                {

                    ChangeParent(bracket.Parent, elements[index]);

                }

                enumerator.MovePreviousClosedBranch();
                DestroyBracket(bracket);



            }

            else
            {
                bracket.MovedBracket = true;
                enumerator.MovePreviousClosedBranch();

            }





        }


        private void ChangeParent(VariablesDate bracketParent, VariablesDate bracketElement)
        {
            bracketParent.DataList.Add(bracketElement);

            foreach (var element in bracketParent.DataList)
            {
                element.Parent = bracketParent.Self;

            }

        }
        /// <summary>
        /// Чекает, может ли скобка, перевести все свои выражения в пространство своего родителя
        /// </summary>
        /// <param name="verifiable"></param>
        /// <returns></returns>
        private bool CheckPermission(VariablesDate verifiable)
        {
            if (!verifiable.Closed && verifiable.Parent.Var != "^" && verifiable.Parent.Var != "/")
            {
                return true;

            }
            else

                return false;

        }

        private void DestroyBracket(VariablesDate target)
        {
            target.Parent.DataList.RemoveAt(target.Index);

        }

    }
}
