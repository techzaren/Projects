﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.Shapers.Data;
using EqParser.Shapers;
using EqParser.Shapers.ShapersEnumerators;
using EqParser.SyntLexems;


namespace EqParser.Shapers
{
    class BracketDisclosures
    {
        private List<Dictionary<float, string>> _coeffDictionary = new List<Dictionary<float, string>>();

        

        private Dictionary<float, string> CoeffDictionary
        {
            get { return _coeffDictionary.Last(); }
            set { _coeffDictionary.Add(value); }

        }

        private List<Dictionary<float, string>> CoeffList
        {
            get { return _coeffDictionary; }

        }



        #region Методы
        public void OpenBrackets(VariablesDate someDataPart)
        {
            var threeRoot = someDataPart;
            var optimizeIsOver = false;
            CoeffDictionary = AddUnitaryMultiplier(1f);

            using (var enumerator = new BranchEnumerator(threeRoot))
            {
                while (!optimizeIsOver)
                {
                    if (GetLastNotOptimizedThree(enumerator).Self != threeRoot.Self)
                    {
                        if (enumerator.MainBranch.Var == "/" || enumerator.MainBranch.Var == "^")
                        {
                            enumerator.MainBranch.BracketOptimizedThree = true;
                            CoeffList.RemoveAt(CoeffList.Count - 1);
                            enumerator.MovePreviousClosedBranch();
                        }
                        else
                        {
                            Multiplier(enumerator);

                            enumerator.NotOptimizedThree = enumerator.MainBranch.Index;

                            enumerator.MovePreviousClosedBranch();

                            enumerator.SetIndex = enumerator.NotOptimizedThree;

                            if (enumerator.MoveNext())
                            {
                                if (enumerator.Current.Var != "^" && enumerator.Current.Var != "/")
                                {
                                    enumerator.MoveBack();
                                    enumerator.Current.Closed = false;

                                }
                                else
                                {
                                    enumerator.Reset();
                                    
                                }

                            }
                            else
                            {
                                enumerator.MoveBack();
                                enumerator.Current.Closed = false;
                            
                            }



                        }


                    }

                    else
                    {
                        
                        optimizeIsOver = true;

                    }
                }

            }

        }

        /// <summary>
        /// Если у текущей ветви есть множитель, проверяет можно ли умножать
        /// Начинает работу с самого последнего выражения самой первой ветви типа (...)  /... или ^...
        /// </summary>
        /// <param name="enumerator"></param>
        /// <returns></returns>
        private VariablesDate GetLastNotOptimizedThree(BranchEnumerator enumerator)
        {
            while (enumerator.MoveNextClosedBranch())
            {
                var multiplier = enumerator.GetMultiplier();

                if (multiplier != null)
                {
                    

                    if (enumerator.BranchList.Count > enumerator.CurrentBranchIndex + 2)
                    {
                        if (enumerator.BranchList[enumerator.CurrentBranchIndex + 2].Var != "^")
                        {
                            enumerator.BranchList[enumerator.CurrentBranchIndex + 1].Index--;
                            enumerator.BranchList.RemoveAt(enumerator.CurrentBranchIndex);

                        }
                        else
                        {
                            if (IsUnitary(multiplier, CoeffDictionary))
                            {
                                float coeff = multiplier.Coeff * CoeffDictionary.Last().Key;
                                if (coeff > 0)
                                {
                                    enumerator.BranchList[enumerator.CurrentBranchIndex + 1].Sign = Symbols.Plus;

                                }
                                else
                                {
                                    enumerator.BranchList[enumerator.CurrentBranchIndex + 1].Sign = Symbols.Minus;
                                }

                                enumerator.BranchList[enumerator.CurrentBranchIndex + 1].Index--;
                                enumerator.BranchList.RemoveAt(enumerator.CurrentBranchIndex);

                            
                            }

                            
                                CoeffList.RemoveAt(CoeffList.IndexOf(CoeffDictionary));
                                CoeffDictionary = AddUnitaryMultiplier(1f);

                            

                           
                        
                        }

                    }
                    else
                    {
                        enumerator.BranchList[enumerator.CurrentBranchIndex + 1].Index--;
                        enumerator.BranchList.RemoveAt(enumerator.CurrentBranchIndex);

                    }

                    CoeffDictionary = MergeMultiplier(multiplier);
                }
                else
                {

                   
                        CoeffDictionary = AddUnitaryMultiplier(1f);
                   


                }

                enumerator.Reset();
                enumerator.MoveNextClosedBranch();


            }

      
            return enumerator.MainBranch;

        }


        private void Multiplier(BranchEnumerator enumerator)
        {

            VariablesDate bracketExpressions = enumerator.MainBranch;

            float coeff = CoeffDictionary.Last().Key;
            string identificatorCoeff = CoeffDictionary.Last().Value;

            var bracketElements = bracketExpressions.DataList.Where(el => (el.Var[0] == '#' || char.IsLetter(el.Var[0])));

            if (enumerator.MainBranch.Parent.DataList.Count > enumerator.MainBranch.Index + 1)
            {
                if (enumerator.MainBranch.Parent.DataList[enumerator.MainBranch.Index + 1].Var != "^")
                {
                    foreach (var elements in bracketElements)
                    {
                        MultiplierHelper(elements, coeff, identificatorCoeff);
                    }

                }

            }

            else
            {
                foreach (var elements in bracketElements)
                {
                    MultiplierHelper(elements, coeff, identificatorCoeff);
                }

            }

            enumerator.MainBranch.BracketOptimizedThree = true;
            CoeffList.RemoveAt(CoeffList.Count - 1);

        }

        private bool IsUnitary(VariablesDate multiplier, Dictionary<float, string> coeff)
        {
            if (multiplier.Var == "#" && coeff.Last().Value == "#")
            {
                if (multiplier.Coeff == 1.0f || multiplier.Coeff == -1.0f)
                {
                    if (coeff.Last().Key == 1.0f || coeff.Last().Key == -1.0f)
                    {
                        return true;
                    
                    }

                    return false;

                }
                
                    return false;
            
            }
            

            return false;
        }

        private void MultiplierHelper(VariablesDate element, float coeff, string identificatorCoeff)
        {

            float tempCoeff = coeff * element.Coeff;
            var tempIdentificator = identificatorCoeff + element.Var;

            char[] tempArray = tempIdentificator.ToCharArray();
            Array.Sort(tempArray);
            tempIdentificator = new String(tempArray);

            element.Coeff = tempCoeff;
            element.Var = tempIdentificator;

            if (element.Var == "##")
            {
                element.Var = "#";

            }
            else
            {
                element.Var = element.Var.Replace("#", string.Empty);

            }


        }

        private Dictionary<float, string> MergeMultiplier(VariablesDate inputCoeff)
        {
            if ((inputCoeff.Var == "#") && (CoeffDictionary.Last().Value == "#"))
            {
                float coeff = inputCoeff.Coeff * CoeffDictionary.Last().Key;

                var newDict = new Dictionary<float, string>();
                newDict.Add(coeff, "#");
                return newDict;

            }
            else
            {
                float coeff = inputCoeff.Coeff * CoeffDictionary.Last().Key;
                string identificatorCoeff = (inputCoeff.Var + CoeffDictionary.Last().Value);

                identificatorCoeff = identificatorCoeff.Replace("#", string.Empty);


                char[] tempArray = identificatorCoeff.ToCharArray();
                Array.Sort(tempArray);
                identificatorCoeff = new String(tempArray);

                var newDict = new Dictionary<float, string>();
                newDict.Add(coeff, identificatorCoeff);

                return newDict;


            }

        }


        private Dictionary<float, string> AddUnitaryMultiplier(float coeff)
        {
            var newDict = new Dictionary<float, string>();
            newDict.Add(coeff, "#");

            return newDict;

        }

        #endregion


    }
}
