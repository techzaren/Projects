﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;

namespace EqParser.Shapers.Data
{
    /// <summary>
    /// Содержит в себе правую и левую часть уравнения
    /// </summary>
   sealed public class Keeper
    {
        private readonly VariablesDate _leftPart;
        private readonly VariablesDate _rightPart;



        public VariablesDate LeftPart
        {
            get { return _leftPart; }
        }

        public VariablesDate RightPart
        {
            get { return _rightPart; }
        }

       

        public Keeper(VariablesDate leftPart = null, VariablesDate rightPart = null)
        {
            _leftPart = leftPart ?? new VariablesDate().Empty();
            _rightPart = rightPart ?? new VariablesDate().Empty(); ;
        
        }

    }
}
