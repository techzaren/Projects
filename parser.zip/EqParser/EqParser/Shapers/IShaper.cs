﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.Shapers.Data;

namespace EqParser.Shapers
{
    interface IShaper
    {
        Keeper Shape(Keeper keeper);


    }
}
