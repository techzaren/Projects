﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;
using EqParser.Shapers.ShapersEnumerators;

namespace EqParser.Shapers
{
    class ResultReader
    {
        StringBuilder resultString = new StringBuilder();
        private delegate string ReadMethod(VariablesDate element, int index);

        private ReadMethod _method;

        private ReadMethod Read
        {
            get { return _method; }
            set { _method = value; }

        }

        public string ReadResult(VariablesDate result)
        {
            var threeRoot = result;
            var optimizeIsOver = false;
            int from = 0;
            StringBuilder tempResult = new StringBuilder();
            


            using (var enumerator = new RecordingEnumerator(threeRoot))
            {
                while (!optimizeIsOver)
                {
                    if (GetLastNotReadedThree(enumerator).Self != threeRoot.Self)
                    {

                        enumerator.MainBranch.Readed = true;


                        from = GetLastNotReadedElement(enumerator.MainBranch.DataList);

                        if (from > -1)
                        {
                            resultString.Append(ReadAndRecord(enumerator.MainBranch.DataList, from, enumerator.CurrentBranchIndex-1));

                        }

                        

                        if (enumerator.MainBranch.Var == "(" && !enumerator.MainBranch.RightBracketIsWritten)
                        {
                            
                            resultString.Append(")");
                            enumerator.MainBranch.RightBracketIsWritten = true;
                        
                        }

                        enumerator.MovePreviousClosedBranch();


                    }

                    else
                    {
                        

                        from = GetLastNotReadedElement(enumerator.MainBranch.DataList);

                        if (from > -1)
                        {
                            resultString.Append(ReadAndRecord(enumerator.MainBranch.DataList, from, enumerator.CurrentBranchIndex - 1));

                        }

                        Console.WriteLine("Результат:");
                        optimizeIsOver = true;

                    }
                }

            }


            return resultString.ToString();

        }
        /// <summary>
        /// Перебирает не пройденные ветки и заходит вглубь. В случае завершения, ставит флаг Readed true
        /// </summary>
        /// <param name="enumerator"></param>
        /// <returns></returns>
        private VariablesDate GetLastNotReadedThree(RecordingEnumerator enumerator)
        {

            int from = 0;

            while (enumerator.MoveNextClosedBranch())
            {

                from = GetLastNotReadedElement(enumerator.MainBranch.DataList);

                if (from > -1)
                {
                    if (enumerator.CurrentBranchIndex < enumerator.MainBranch.DataList.Count)
                    {
                        resultString.Append(ReadAndRecord(enumerator.MainBranch.DataList, from, enumerator.CurrentBranchIndex));
                        enumerator.MainBranch = enumerator.Current;
                        enumerator.MainBranch.Index = enumerator.NotOptimizedThree;

                    }
                    else
                    {

                        resultString.Append(ReadAndRecord(enumerator.MainBranch.DataList, from, enumerator.CurrentBranchIndex-1));
                        enumerator.MainBranch = enumerator.Current;
                        enumerator.MainBranch.Index = enumerator.NotOptimizedThree;
                        
                    }
                    
                    

                }
                else
                    enumerator.MovePreviousClosedBranch();
                

            }


            return enumerator.MainBranch;

        }

        private int GetLastNotReadedElement(List<VariablesDate> elements)
        {
            //foreach (var el in elements)
            //{
            //    if (!el.Readed)
            //    {
            //        return elements.IndexOf(el);

            //    }


            //}

            for (int index = 0; index < elements.Count; index++)
            {
                if (!elements[index].Readed)
                {
                    return index;

                }


            }


            return -1;

        }

        private string ReadAndRecord(List<VariablesDate> readingList, int from, int lastIndex)
        {
            StringBuilder str = new StringBuilder();
            for (int index = from; index <= lastIndex; )
            {
                GetReadMethod(readingList[index]);

                str.Append(Read(readingList[index], index));

                readingList[index].Readed = true;
                ++index;
            }

            return str.ToString();

        }

        /// <summary>
        /// Автоматически определяет необходимый метод чтения с помощью делегата ReadMethod (Read)
        /// </summary>
        /// <param name="readingElement"></param>
        private void GetReadMethod(VariablesDate readingElement)
        {

            switch (readingElement.Var[0])
            {

                case '(':
                    Read = ReadBracket;
                    break;

                case '#':
                    Read = ReadDigit;
                    break;

                case '^':
                    Read = ReadDivisionOrDegree;
                    break;

                case '/':
                    Read = ReadDivisionOrDegree;
                    break;

                default:
                    Read = ReadIdentificator;
                    break;



            }


        }


        string ReadBracket(VariablesDate bracket, int index)
        {
            if (index == 0)
            {
                if (bracket.Sign == '-' || bracket.Coeff < 0)
                {
                    return "-(";
                
                }
                else
                    return "(";
            
            }

            switch (bracket.Sign)
            {
                case '*':
                    return "(";


                case '-':
                    return "-(";


                case '+':
                    return "+(";

            }

            return "(";
        }

        string ReadDivisionOrDegree(VariablesDate symbol, int index)
        {
            switch (symbol.Var)
            {
                case "/":
                    return "/";


                case "^":
                    return "^";

            }

            return "";

        }

        string ReadDigit(VariablesDate digit, int index)
        {
            if (digit.Parent.Var != "^" && digit.Parent.Var != "/")
            {
                if (digit.Coeff > 0 && index > 0)
                {
                    return "+" + digit.Coeff.ToString();

                }
                else
                {
                    return digit.Coeff.ToString();

                }



            }

            else
            {

                return digit.Coeff.ToString();


            }



        }

        string ReadIdentificator(VariablesDate identificator, int index)
        {
            if (identificator.Parent.Var != "^" && identificator.Parent.Var != "/")
            {

                if (((int)(identificator.Coeff)) == 1 && index > 0)
                {
                    return "+" + identificator.Var;
                }


                if (((int)(identificator.Coeff)) == -1 && index > 0)
                {
                    return "-" + identificator.Var;

                }

                if ((identificator.Coeff > 0.0009) && (index > 0))
                {
                    return "+" + identificator.Coeff.ToString() + identificator.Var;

                }

                if (((int)(identificator.Coeff)) == 1 && index == 0)
                {
                    return identificator.Var;

                }

                return identificator.Coeff.ToString() + identificator.Var;

            }
            else
            {
                if (identificator.Coeff == 1.0f)
                {
                    return identificator.Var;
                }

                if (identificator.Coeff == -1.0f)
                {
                    return "-" + identificator.Var;

                }


                return identificator.Coeff.ToString() + identificator.Var;

            }

        }

    }
}
