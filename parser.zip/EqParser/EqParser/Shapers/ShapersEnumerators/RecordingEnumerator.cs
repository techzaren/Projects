﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;

namespace EqParser.Shapers.ShapersEnumerators
{
   public class RecordingEnumerator: TermsEnumerator
    {



        sealed public override bool MoveNextClosedBranch()
        {

            while (MoveNext())
            {
                if (!Current.Readed && (Current.Var == "(" || Current.Var == "/" || Current.Var == "^"))
                {
                    NotOptimizedThree = CurrentBranchIndex;
                    

                    return true;

                }

            }


            return false;
        }

         #region Конструкторы
        public RecordingEnumerator(VariablesDate branch)
            : base(branch)
        {


        }
        #endregion

    }
}
