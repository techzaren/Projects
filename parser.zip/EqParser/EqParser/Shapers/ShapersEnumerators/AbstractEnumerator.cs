﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;
using EqParser.Readers;

namespace EqParser.Shapers.ShapersEnumerators
{
    /// <summary>
    /// Самый главный перечислитель
    /// </summary>
    public abstract class AbstractEnumerator : IEnumerator, IDisposable
    {
        #region Переменные
        private VariablesDate _mainBranch;
        private List<VariablesDate> _currentBranchList;
        private VariablesDate _currentBranch;
        private int _currentBranchIndex;
        private int _notOptimizedThree;

        #endregion

        public abstract bool MoveNextClosedBranch();

        public abstract VariablesDate GetMultiplier();

        #region Свойства
        object IEnumerator.Current
        {
            get { return Current; }

        }
        



        public VariablesDate Current
        {
            get
            {
                if (_currentBranchIndex < 0 || _currentBranchIndex >= _currentBranchList.Count)
                    throw new InvalidOperationException("on the index tree is not exist");

                return _currentBranchList[_currentBranchIndex];
            }
        }


        public int CurrentBranchIndex
        {
            get { return _currentBranchIndex; }


        }

        public List<VariablesDate> BranchList
        {
            get { return _currentBranchList; }

        }



        public VariablesDate MainBranch
        {
            get { return _mainBranch; }
            set { _mainBranch = NewMainBranch(value); }

        }


        public int NotOptimizedThree
        {
            get { return _notOptimizedThree; }
            set { _notOptimizedThree = value; }

        }

        public int SetIndex
        {

            set { _currentBranchIndex = value; }

        }

        
        public List<VariablesDate> InputBranchList
        {
            get { return _currentBranchList; }
            set { _currentBranchList = value; }

        }


        public bool IsHasValue
        {
            get { return _currentBranchIndex >= 0 && _currentBranchIndex < _currentBranchList.Count; }
        }

        public bool IsLast
        {
            get { return _currentBranchIndex >= 0 && _currentBranchIndex == _currentBranchList.Count - 1; }
        }

        #endregion

        #region Методы
        public bool MoveNext()
        {
            if (_currentBranchIndex < (_currentBranchList.Count - 1))
            {
                _currentBranchIndex++;
                _currentBranch = _currentBranchList[_currentBranchIndex];
                return true;
            }

            _currentBranchIndex = _currentBranchList.Count;
            return false;
        }


        public bool MoveBack()
        {
            if (_currentBranchIndex > 0)
            {
                _currentBranchIndex--;

                return true;
            }


            return false;
        }

        public VariablesDate MovePreviousClosedBranch()
        {
            MainBranch = MainBranch.Parent;



            return MainBranch;

        }

        public VariablesDate NewMainBranch(VariablesDate newMainBranch)
        {

            _mainBranch = newMainBranch;

            _currentBranchList = _mainBranch.DataList;
            //_currentBranch
            _currentBranch = MainBranch;

            _currentBranchIndex = -1;

            return _mainBranch;


        }

       

        public void Reset()
        {
            MainBranch = MainBranch; // сбрасываем только индекс, остаёмся в текущей ветке
            NotOptimizedThree = 0;
        }

        public void Dispose()
        {
            if (_currentBranchList != null)
                _currentBranchIndex = _currentBranchList.Count-1;

            _mainBranch = null;
            _currentBranchList = null;
            _currentBranch = null;
        }


        public void NewEmptyBranch()
        {
            MainBranch.AddNewBranch(new VariablesDate().Empty(MainBranch));

        }

        public void DeleteBranch(int index)
        {
            MainBranch.DataList.RemoveAt(index);


        }

        public void DeleteBranch()
        {
            MainBranch.DataList.RemoveAt(NotOptimizedThree);


        }


        #endregion

        #region Конструкторы
        public AbstractEnumerator(VariablesDate branch)
        {
            if (branch == null)
            {
                throw new ArgumentNullException("Branch is null");
            }
            else

                _mainBranch = branch;
            _currentBranchList = branch.DataList;
            //_currentBranch

            _currentBranchIndex = -1;
        }


        public AbstractEnumerator()
        {

        }


        #endregion




    }



}
