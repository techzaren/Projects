﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;
using EqParser.Readers;

namespace EqParser.Shapers.ShapersEnumerators
{
    public class BranchEnumerator : AbstractEnumerator
    {

       sealed public override VariablesDate GetMultiplier()
        {
            NotOptimizedThree = MainBranch.Index;
            MovePreviousClosedBranch();
            if (MainBranch.DataList[NotOptimizedThree].Closed && (MainBranch.DataList[NotOptimizedThree].Var == "("))
            {
                SetIndex = NotOptimizedThree;

                if (MoveBack())
                {
                    if (Current.Closed && (Current.Var == "#" || char.IsLetter(Current.Var[0])))
                    {
                        return Current;

                    }

                }

            }


            return null;

        }

      sealed  public override bool MoveNextClosedBranch()
        {

            while (MoveNext())
            {
                if (!Current.BracketOptimizedThree && (Current.Var == "(" || Current.Var == "/" || Current.Var == "^"))
                {
                    NotOptimizedThree = CurrentBranchIndex;
                    MainBranch = Current;
                    MainBranch.Index = NotOptimizedThree;

                    return true;

                }

            }


            return false;
        }





        #region Конструкторы
        public BranchEnumerator(VariablesDate branch)
            : base(branch)
        {


        }

        #endregion




    }
}
