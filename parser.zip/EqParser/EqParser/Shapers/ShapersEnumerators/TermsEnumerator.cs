﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;
using EqParser.Readers;

namespace EqParser.Shapers.ShapersEnumerators
{
    public class TermsEnumerator : AbstractEnumerator
    {


      sealed  public override VariablesDate GetMultiplier()
        {
            return null;
        }

        public override bool MoveNextClosedBranch()
        {

            while (MoveNext())
            {
                if (!Current.TermsOptimizedThree && (Current.Var == "(" || Current.Var == "/" || Current.Var == "^"))
                {
                    NotOptimizedThree = CurrentBranchIndex;
                    MainBranch = Current;
                    MainBranch.Index = NotOptimizedThree;

                    return true;

                }

            }


            return false;
        }


        #region Конструкторы
        public TermsEnumerator(VariablesDate branch)
            : base(branch)
        {


        }
        #endregion

    }



}
