﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;

namespace EqParser.Shapers.ShapersEnumerators
{
    class MovingEnumerator: TermsEnumerator
    {
        
        sealed public override bool MoveNextClosedBranch()
        {

            while (MoveNext())
            {
                if (!Current.MovedBracket && (Current.Var == "(" || Current.Var == "/" || Current.Var == "^"))
                {
                    NotOptimizedThree = CurrentBranchIndex;
                    MainBranch = Current;
                    MainBranch.Index = NotOptimizedThree;

                    return true;

                }

            }


            return false;
        }


         #region Конструкторы
        public MovingEnumerator(VariablesDate branch)
            : base(branch)
        {


        }
        #endregion

    }
}
