﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqParser.Errors
{
    public static class ErrorsList
    {
        public static Action<string> Messadger;

        public static string _nullPrecedence = "Выражение введено некорректно, \nОтношения предшествования между символами ";
        public static string _repeat = "Введите выражение заново";
        public static string _invalidCharacter = "Вы ввели недопустимый символ ";
        public static string _doesNotExist = " не существует ";
        public static string _emptyEquation = "Вы ничего не ввели, побробуйте снова";
        public static string _cantStart = "Выражение не может начинаться с оператора ";
        public static string _cantFinish = "Выражение не может заканчиваться оператором ";
        public static string _bracketBalance = "Нарушен баланс скобок";


    }
}
