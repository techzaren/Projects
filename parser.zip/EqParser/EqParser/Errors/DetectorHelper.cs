﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;
using EqParser.Readers;

namespace EqParser.Errors
{
    sealed public class DetectHelper
    {

        private Precedence precedence = new Precedence();
        public char precedenceResult;

        /// <summary>
        /// Ищет ошибки в выражении
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public string LookForErrors(string inputStr)
        {

            using (MyCharEnumerator charPointer = new MyCharEnumerator(inputStr), secondCharPointer = new MyCharEnumerator(inputStr, 0))
            {
                secondCharPointer.MoveNext();

                while (charPointer.MoveNext() && secondCharPointer.IsHasValue)
                {
                    if (char.IsLetter(charPointer.Current) || char.IsDigit(charPointer.Current) || precedence.SI.Contains(charPointer.Current))
                    {
                        if (char.IsLetter(secondCharPointer.Current) || char.IsDigit(secondCharPointer.Current) || precedence.SI.Contains(secondCharPointer.Current))
                        {
                            precedenceResult = CalculatePrecedence(charPointer.Current, secondCharPointer.Current);

                            if (precedenceResult == '0')
                            {
                                if (charPointer.Current == '#')
                                {
                                    ErrorsList.Messadger(ErrorsList._cantStart + secondCharPointer.Current);
                                    return null;
                                }

                                if (secondCharPointer.Current == '#')
                                {
                                    ErrorsList.Messadger(ErrorsList._cantFinish + charPointer.Current);
                                    return null;
                                }

                                ErrorsList.Messadger(ErrorsList._nullPrecedence + charPointer.Current + " и " + secondCharPointer.Current + ErrorsList._doesNotExist + Environment.NewLine + ErrorsList._repeat);
                                return null;
                            }

                            secondCharPointer.MoveNext();

                        }

                        else
                        {
                            ErrorsList.Messadger(ErrorsList._invalidCharacter + secondCharPointer.Current + Environment.NewLine + ErrorsList._repeat + "!!!");
                            return null;
                        }

                    }

                    else
                    {
                        ErrorsList.Messadger(ErrorsList._invalidCharacter + charPointer.Current + Environment.NewLine + ErrorsList._repeat);
                        return null;
                    }

                }

            }

            return inputStr.Replace("#", string.Empty);

        }


        private char CalculatePrecedence(char left, char right)
        {
            char leftSymbol = precedence.LexemIdentificator(left);
            char rightSymbol = precedence.LexemIdentificator(right);

            return precedence.GetPrecedence(leftSymbol, rightSymbol);
        }


        public void WrtToConsole(string str)
        {

            Console.WriteLine(str);

        }

        public DetectHelper()
        {
            ErrorsList.Messadger = WrtToConsole;

        }

    }
}
