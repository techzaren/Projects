﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EqParser.SyntLexems;

namespace EqParser.Readers
{
    sealed public class ReadDegree : ReadLeftBracket
    {
        #region Конструкторы
        public ReadDegree()
        {
            this.Var = "^";
            this.Symbol = Symbols.DegreeSymbol;
        }
        #endregion

    }
}
