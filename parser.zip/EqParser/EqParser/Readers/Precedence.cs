﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqParser.Readers
{
    sealed public class Precedence
    {
        #region Переменные
        

        public char[] SI = new char[] { '#', 'i', 'k', '+', '-', '=', '/', '^', '.', '(', ')', '*' };
        public char[] SJ = new char[] { '#', 'i', 'k', '+', '-', '=', '/', '^', '.', '(', ')', '*' };

        #region Матрица предшествования
        public char[,] precedenceMatrix = new char[,]
        {
                         //  {'', '', '', '', '', '', '', '', '', '', '', ''},

//            #    i    k    +    -    =    /    ^    .    (    )    * 
            {'0', '<', '<', '<', '<', '0', '0', '0', '0', '<', '0', '0'}, // #
            {'>', '=', '0', '>', '>', '>', '/', '^', '0', '(', ')', '0'}, // i
            {'>', '>', '=', '>', '>', '>', '/', '^', '=', '(', ')', '0'}, // k
            {'0', '<', '<', '0', '0', '0', '0', '0', '0', '[', '0', '0'}, // +
            {'0', '<', '<', '0', '0', '0', '0', '0', '0', '[', '0', '0'}, // -
            {'0', '<', '<', '<', '<', '0', '0', '0', '0', '<', '0', '0'}, // =
            {'0', '<', '<', '0', '<', '0', '0', '0', '0', '[', '0', '0'}, // /
            {'0', '<', '<', '0', '<', '0', '0', '0', '0', '[', '0', '0'}, // ^
            {'0', '0', '=', '0', '0', '0', '0', '0', '0', '0', '0', '0'}, // .
            {'0', '<', '<', '0', '<', '0', '0', '0', '0', '~', '0', '0'}, // (
            {'>', '0', '0', '<', '<', '>', '/', '^', '0', '0', ')', '0'}, // )
            {'0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'}  // *
        };
        #endregion

        #endregion

        #region Методы
        public char GetPrecedence(char I, char J)  //вычисление предществования между символами
        {
            int si, sj;
            si = sj = 0;
            for (int i = 0; i < SI.Count(); i++)
            {
                if (I == SI[i]) si = i;
                if (J == SJ[i]) sj = i;
            }
            return precedenceMatrix[si, sj];
        }

        /// <summary>
        /// Преобразовать переменные в идентификаторы - i, константы в - k
        /// </summary>
        /// <param name="InputChar"></param>
        /// <returns></returns>
        public char LexemIdentificator(char InputChar)
        {

            if (char.IsDigit(InputChar))
            {
                return Convert.ToChar("k");

            }
            else
                if (char.IsLetter(InputChar))
                {
                    return Convert.ToChar("i");

                }
                else
                    return InputChar;
        }
        #endregion

    }
}
