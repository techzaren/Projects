﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;

namespace EqParser.Readers
{
    public class ExpressionsCreator
    {
        #region Переменные
        public delegate VariablesDate MethodSelectorDelegate(VariablesDate mainThree, string tempLexem);
        private MethodSelectorDelegate _methodSelector;

        public MethodSelectorDelegate MethodSelector
        {
            get { return _methodSelector; }
            private set { _methodSelector = value; }
        }

        private ReadHelper readhelper = new ReadHelper();
        private ReadLeftBracket readLeftBracket = new ReadLeftBracket();
        private ReadDivision readDivision = new ReadDivision();
        private ReadDegree readDegree = new ReadDegree();

        #endregion

        #region Методы
        public void SelectRecordingMethod(char precedenceResult)
        {
            switch (precedenceResult)
            {

                case '>':
                    MethodSelector = readhelper.ReadFloatDigit;
                    break;


                case '<':
                    MethodSelector = readhelper.ReadOperator;
                    break;


                case '(':
                    MethodSelector = readLeftBracket.Read;
                    break;

                case ')':
                    MethodSelector = readhelper.ReturnPreviousReader;
                    break;

                case '[':
                    MethodSelector = readhelper.ReadMultiplier;
                    break;

                case '/':
                    MethodSelector = readDivision.Read;
                    break;

                case '^':
                    MethodSelector = readDegree.Read;
                    break;

                case 'L':
                    MethodSelector = readhelper.ReadLastLexem;
                    break;
            }

        }
        #endregion

    }
}
