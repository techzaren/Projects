﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EqParser.SyntLexems;

namespace EqParser.Readers
{
    public class ReadLeftBracket
    {
        #region Переменные
        private string _var = "(";
        private char _symbol = Symbols.Multiplication;
        protected ReadHelper readHelper;
        #endregion

        #region Свойства
        protected string Var
        {
            get { return _var; }
            set { _var = value; }

        }

        protected char Symbol
        {
            get { return _symbol; }
            set { _symbol = value; }

        }
        #endregion

        #region Методы
        public VariablesDate Read(VariablesDate mainThree, string tempLexem)
        {

            mainThree.AlreadyWritten = true;
            mainThree.Closed = true;


            if (tempLexem != ")")
            {
                mainThree.Parent.AddNewBranch(readHelper.ReadLastLexem(mainThree, tempLexem));

            }
            else
            {
                readHelper.ReadLastLexem(mainThree, tempLexem);

            }




            if ((Var == "/" || Var == "^") && (mainThree.Parent.Var == "/" || mainThree.Parent.Var == "^"))
            {
                mainThree.Parent.Parent.CreateNewBranch(alreadyWritten: true, closed: true, sign: _symbol, var: _var);

              
                return mainThree.Parent.Parent.DataList[mainThree.Parent.Parent.DataList.Count - 1];


            }
            else
            {

                mainThree.Parent.CreateNewBranch(alreadyWritten: true, closed: true, sign: _symbol, var: _var);

                
                return mainThree.Parent.DataList[mainThree.Parent.DataList.Count - 1];
            }


        }

        #endregion

        #region Конструкторы
        public ReadLeftBracket()
        {
            readHelper = new ReadHelper();

        }

        #endregion

    }
}
