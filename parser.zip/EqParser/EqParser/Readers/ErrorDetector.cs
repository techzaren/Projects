﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;
using EqParser.Errors;


namespace EqParser.Readers
{
    sealed public class ErrorDetector
    {
        private DetectHelper detectorHelper = new DetectHelper();

        //public delegate bool Checker(string str);
        //public static Checker checker;

        private Precedence precedence = new Precedence();
        private char precedenceResult;
        public string CheckedString;

        #region Методы
        public string DetectError(string inputStr)
        {

            if (inputStr != null)
            {
                inputStr = WithoutSpace(inputStr);


                inputStr = "#" + inputStr + "#";

                if (inputStr.Length == 2)
                {
                    ErrorsList.Messadger(ErrorsList._emptyEquation);
                    return null;

                }
                else
                {
                    if (CheckBracketBalance(inputStr))
                    {
                        CheckedString = detectorHelper.LookForErrors(inputStr);

                        return CheckedString;
                    }

                    else
                    {
                        return null;
                    }


                }

            }

            return null;
        }


        private String WithoutSpace(string st)
        {
            //st = st.Replace(" ", string.Empty);

            StringBuilder str = new StringBuilder();
            foreach (var ch in st)
            {
                if (ch != ' ')
                {
                    str.Append(ch);
                }

            }

            Console.WriteLine("Исходное выражение: \n");
            Console.WriteLine(str);
            return str.ToString();
        }

        private bool CheckBracketBalance(string str)
        {
            int leftBracket = 0;
            int rightBracket = 0;

            foreach (var ch in str)
            {
                if (ch == '(')
                {
                    leftBracket++;
                }

                if (ch == ')')
                {
                    rightBracket++;
                }

            }

            if (leftBracket == rightBracket)
            {
                return true;
            }
            else
            {
                ErrorsList.Messadger(ErrorsList._bracketBalance + "\n" + ErrorsList._repeat);
                return false;
            }
        }


        private char CalculatePrecedence(char left, char right)
        {
            char leftSymbol = precedence.LexemIdentificator(left);
            char rightSymbol = precedence.LexemIdentificator(right);

            return precedence.GetPrecedence(leftSymbol, rightSymbol);
        }


        private bool LookForErrors(string inputStr)
        {
            using (MyCharEnumerator charPointer = new MyCharEnumerator(inputStr), secondCharPointer = new MyCharEnumerator(inputStr, 0))
            {

                secondCharPointer.MoveNext();

                while (charPointer.MoveNext() && secondCharPointer.IsHasValue)
                {
                    if (char.IsLetter(charPointer.Current) || char.IsDigit(charPointer.Current) || precedence.SI.Contains(charPointer.Current))
                    {
                        if (char.IsLetter(secondCharPointer.Current) || char.IsDigit(secondCharPointer.Current) || precedence.SI.Contains(secondCharPointer.Current))
                        {
                            precedenceResult = CalculatePrecedence(charPointer.Current, secondCharPointer.Current);

                            if (precedenceResult == '0')
                            {
                                if (charPointer.Current == '#')
                                {
                                    ErrorsList.Messadger(ErrorsList._cantStart + secondCharPointer.Current);
                                    return false;
                                }

                                if (secondCharPointer.Current == '#')
                                {
                                    ErrorsList.Messadger(ErrorsList._cantFinish + charPointer.Current);
                                    return false;
                                }

                                ErrorsList.Messadger(ErrorsList._nullPrecedence + charPointer.Current + " и " + secondCharPointer.Current + ErrorsList._doesNotExist + Environment.NewLine + ErrorsList._repeat);
                                return false;
                            }

                            secondCharPointer.MoveNext();

                        }

                        else
                        {
                            ErrorsList.Messadger(ErrorsList._invalidCharacter + secondCharPointer.Current + Environment.NewLine + ErrorsList._repeat + "!!!");
                            return false;
                        }

                    }

                    else
                    {
                        ErrorsList.Messadger(ErrorsList._invalidCharacter + charPointer.Current + Environment.NewLine + ErrorsList._repeat + "&&&");
                        return false;
                    }

                }

            }

            return true;

        }

        #endregion




    }
}
