﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EqParser.SyntLexems;

namespace EqParser.Readers
{
    sealed public class ReadDivision : ReadLeftBracket
    {
        #region Конструкторы
        public ReadDivision()
        {
            this.Var = "/";
            this.Symbol = Symbols.Division;

        }
        #endregion
    }
}
