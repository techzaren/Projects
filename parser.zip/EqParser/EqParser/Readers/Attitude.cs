﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqParser.Readers
{
   public static class Attitude
    {
        public const char Head = '<';
        public const char Tail = '>';
        public const char LeftBracket = '(';
        public const char RightBracket = ')';
        public const char Belongs = '=';
        public const char Division = '/';
        public const char Degree = '^';
        public const char LastLexem = 'L';
        

    }
}
