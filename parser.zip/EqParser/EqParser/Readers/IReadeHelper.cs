﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EqParser.SyntLexems;

namespace EqParser.Readers
{
    interface IReadeHelper
    {
        #region Реализовано

        VariablesDate ReturnPreviousReader(VariablesDate mainThree, string tempLexem, char sign, float coeff, string var, bool closed);

        VariablesDate ReadLastLexem(VariablesDate mainThree, string tempLexem, char sign, float coeff, string var, bool closed);

        VariablesDate ReadFloatDigit(VariablesDate mainThree, string tempLexem, char sign, float coeff, string var, bool closed);

        VariablesDate ReadVariable(VariablesDate mainThree, string tempLexem, char sign, float coeff, string var, bool closed);

        VariablesDate ReadOperator(VariablesDate mainThree, string tempLexem, char sign, float coeff, string var, bool closed);

        float ParseToFloat(string coefficientLexem);
        #endregion

        #region Реализовать

        #endregion
    }
}
