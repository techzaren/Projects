﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EqParser.SyntLexems;

namespace EqParser.Readers
{
    sealed public class ReadHelper
    {
        #region Методы

        /// <summary>
        /// Вернуть управление в ветвь(предку), которая порадила родителя текущего листа
        /// </summary>
        /// <param name="mainThree"></param>
        /// <param name="tempLexem"></param>
        /// <param name="sign"></param>
        /// <param name="coeff"></param>
        /// <param name="var"></param>
        /// <param name="closed"></param>
        /// <returns></returns>
        public VariablesDate ReturnPreviousReader(VariablesDate mainThree, string tempLexem)
        {
            // mainThree.AlreadyWritten = true;
            if (tempLexem != ")")
            {
                mainThree.Parent.AddNewBranch(ReadLastLexem(mainThree, tempLexem));

            }


            // var nextReader = new VariablesDate();



            if (mainThree.Parent.Var == "/" || mainThree.Parent.Var == "^")
            {

                var nextReader = mainThree.Parent.Parent.Parent;
                mainThree = new VariablesDate(nextReader);
                mainThree.AlreadyWritten = true;

                return mainThree;

            }
            else
            {
                var nextReader = mainThree.Parent.Parent;
                mainThree = new VariablesDate(nextReader);
                mainThree.AlreadyWritten = true;

                return mainThree;

            }





        }


        public VariablesDate ReadLastLexem(VariablesDate mainThree, string tempLexem)
        {

            if (mainThree.Parent.Var == "/" || mainThree.Parent.Var == "^")
            {
                mainThree.Closed = true;
            }


            if (char.IsDigit(tempLexem[tempLexem.Length - 1]))
            {
                ReadFloatDigit(mainThree, tempLexem);

            }
            else
            {
                if (char.IsLetter(tempLexem[tempLexem.Length - 1]))
                {
                    char[] tempArray = tempLexem.ToCharArray();
                    Array.Sort(tempArray);                      // сортируем чтобы acb и abc воспринимались как сочетание, а не размещение
                    var _tempLexem = new String(tempArray);
                    ReadVariable(mainThree, _tempLexem);

                }
                else
                {
                    if (tempLexem == "(" && (mainThree.AlreadyWritten == false))
                    {
                        mainThree.AlreadyWritten = true;

                        if (mainThree.Closed)
                        {
                           
                            mainThree.Parent.CreateNewBranch(true, mainThree.Closed, mainThree.Sign, mainThree.Coeff, var: "(");

                        }
                        else
                        {
                            mainThree.SaveData(true, Symbols.Plus, 1.0f, "#");
                            mainThree.Parent.AddNewBranch(mainThree);
                            mainThree.Parent.CreateNewBranch(true, mainThree.Closed, mainThree.Sign, mainThree.Coeff, var: "(");
                        
                        }
                                               

                        

                        return mainThree.Parent.DataList[mainThree.Parent.DataList.Count - 1];
                    }
                    else
                        if (tempLexem == ")" && mainThree.AlreadyWritten == true)
                        {

                            mainThree.NextReader.DataList[mainThree.NextReader.DataList.Count - 1].Closed = true;
                            // для случая, когда встретили ...)^ или )/ и надо закрыть свободный доступ к ( , к которой принадлежит текущая ) после которой ^ или /


                        }

                }
            }

            return mainThree;

        }


        public VariablesDate ReadFloatDigit(VariablesDate mainThree, string tempLexem)
        {
            mainThree.Coeff *= ParseToFloat(tempLexem);
            mainThree.SaveData(mainThree.Closed, mainThree.Sign, mainThree.Coeff, mainThree.Var);
            return mainThree;
        }

        public VariablesDate ReadVariable(VariablesDate mainThree, string tempLexem)
        {
            string tempVar = tempLexem;
            mainThree.SaveData(mainThree.Closed, mainThree.Sign, mainThree.Coeff, tempVar);

            return mainThree;
        }

        public VariablesDate ReadOperator(VariablesDate mainThree, string tempLexem)
        {
            if (tempLexem == "-")
            {
                mainThree.Coeff *= -1.0f;
                mainThree.SaveData(mainThree.Closed, Symbols.Minus, mainThree.Coeff, mainThree.Var);

            }





            if ((mainThree.Parent.Var == "/" || mainThree.Parent.Var == "^") && mainThree.Parent.DataList.Count > 0)
            {

                mainThree.Parent = mainThree.Parent.Parent;
                mainThree.NextReader = mainThree.Parent;

            }





            return mainThree;

        }


        public VariablesDate ReadMultiplier(VariablesDate mainThree, string tempLexem)
        {
            if ((mainThree.Parent.Var == "/" || mainThree.Parent.Var == "^") && mainThree.Parent.DataList != null)
            {

                mainThree.Parent = mainThree.Parent.Parent;
                mainThree.NextReader = mainThree.Parent;

            }

            if (tempLexem == "-")
            {
                mainThree.SaveData(true, Symbols.Minus, -1.0f, "#");
                mainThree.Parent.AddNewBranch(mainThree);
                return mainThree.Parent.DataList[mainThree.Parent.DataList.Count - 1];


            }

            if (tempLexem == "+")
            {
                mainThree.SaveData(true, Symbols.Plus, 1.0f, "#");
                mainThree.Parent.AddNewBranch(mainThree);
                return mainThree.Parent.DataList[mainThree.Parent.DataList.Count - 1];


            }

            return mainThree;

        }


        private float ParseToFloat(string coefficientLexem)
        {
            return float.Parse(coefficientLexem.Replace('.', ','));
        }

        #endregion

    }
}
